package com.example.Lab3D;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab3DApplicationTests {

	@Test
	void contextLoads() {
	}

}
