package com.example.Lab3D.player.model.dto;

import java.util.UUID;

public class PlayerDTOTemp {
    private UUID id;
    private String name;
    private Integer abilities;
}
